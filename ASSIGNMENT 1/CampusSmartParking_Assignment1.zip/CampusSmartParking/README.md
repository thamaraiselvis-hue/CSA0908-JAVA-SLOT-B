# Campus Smart-Parking System — Assignment 1

**Register number:** 192511042  
**Repository name required by brief:** `CSA09-192511042-Assignment1`  
**Java:** OpenJDK 17+ (tested with the available Java compiler in this environment)

## Project structure
- `src/` — complete Java model, allocation, fee calculation, service and runnable demos.
- `Task01/` … `Task12/` — task-wise evidence folders. Add the matching report notes and any faculty-specific inputs here.
- `docs/UML.puml` — UML class diagram source (PlantUML).
- `docs/Allocation-and-Fee-Pseudocode.txt` — allocation and fee pseudocode.
- `screenshots/` — console screenshots captured from actual program runs.

## Compile
From the project root:

```bash
mkdir -p out
javac -d out src/*.java
```

## Run each demonstration
```bash
java -cp out ParkingFacilityDemo
java -cp out FeeDemo
java -cp out ValidationDemo
java -cp out Task12Demo
```

## Assumptions used in the demonstration
The brief does not prescribe all monetary values. These sample rates are assumptions and must be confirmed with the faculty before final submission:
- Two-wheeler: Rs 10 per started hour.
- Car: Rs 30 per started hour.
- EV charging: Rs 12 per kWh.
- E-bike: Rs 25 flat per non-zero parking session.
- Every started hour is charged in full. Zero minutes costs Rs 0.
- Delivery van: double the car rate for time in `[09:00,17:00)` and normal car rate outside. The sample splits the session by time window and rounds each segment up to a started hour.
- One-day pass: valid only on its specified calendar date; valid visitor pass waives the sample parking fee.

## Test evidence
See `screenshots/` for console captures and `docs/Test-Results.md` for the test table. Re-run the commands above to reproduce the results.

## GitHub setup and one-commit-per-task workflow
Create a repository named `CSA09-192511042-Assignment1` under your GitHub account. Then run:

The downloaded ZIP preserves a local Git history with one commit for each of Task01–Task12. Create an **empty** GitHub repository named `CSA09-192511042-Assignment1` (do not initialise it with a README), then from this extracted project folder run:

```bash
git branch -M main
git remote add origin https://github.com/<YOUR-USERNAME>/CSA09-192511042-Assignment1.git
git push -u origin main
```

The existing local commits will be pushed with the repository. For any later edits, keep committing each task folder separately and run `git push` after each completed task. Replace `<YOUR-USERNAME>` with your GitHub username.

**Do not submit a made-up repository URL or claim commits that have not actually been pushed.** Share the real repository with the faculty (public, or private with faculty as collaborator), as the assignment requires.

## Additional daily-total demonstration
```bash
java -cp out DailyCollectionDemo
```
The sample hand-calculated and program total is Rs 220. UML source is available as `docs/UML.puml` and `docs/UML.dot`; the rendered diagram is `docs/UML.png`.

## Local commit history
This project folder includes an initial project commit followed by one local Git commit for each Task01–Task12 folder. To publish those commits, add your GitHub remote and push the `main` branch using the commands above.
The service also supports a `MonthlyPass` for eligible student/staff monthly validity and an overloaded `exit(..., kWh)` method for EV charging sessions.
