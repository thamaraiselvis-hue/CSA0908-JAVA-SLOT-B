# Task 1

Problem analysis: identify Vehicle, ParkingFacility, ParkingTicket, ParkingService, Pass and PricingRule; define inputs, outputs and invariants.

Common source files are in `../src/`. Compile from the project root with `javac -d out src/*.java`. Run the relevant demo listed in the root README. Add your task-specific report page and the matching screenshot in this folder before committing.
