# Task 2

Data representation: String registration IDs, int floor/slot, LocalDateTime timestamps, long duration and double demo fee; jagged String[][] slots.

Common source files are in `../src/`. Compile from the project root with `javac -d out src/*.java`. Run the relevant demo listed in the root README. Add your task-specific report page and the matching screenshot in this folder before committing.
