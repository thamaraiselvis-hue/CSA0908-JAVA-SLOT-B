# Task 3

Control logic: see docs/Allocation-and-Fee-Pseudocode.txt and ParkingFacilityDemo.java.

Common source files are in `../src/`. Compile from the project root with `javac -d out src/*.java`. Run the relevant demo listed in the root README. Add your task-specific report page and the matching screenshot in this folder before committing.
