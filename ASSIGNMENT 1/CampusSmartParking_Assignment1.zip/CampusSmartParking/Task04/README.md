# Task 4

Constructors and object lifecycle: Vehicle and ParkingTicket use parameterised constructors; ticket IDs use a static counter.

Common source files are in `../src/`. Compile from the project root with `javac -d out src/*.java`. Run the relevant demo listed in the root README. Add your task-specific report page and the matching screenshot in this folder before committing.
