# Task 6

Inheritance: Vehicle → TwoWheeler, Car, EBike, DeliveryVan; Car → ElectricCar. UML is in docs/UML.puml.

Common source files are in `../src/`. Compile from the project root with `javac -d out src/*.java`. Run the relevant demo listed in the root README. Add your task-specific report page and the matching screenshot in this folder before committing.
