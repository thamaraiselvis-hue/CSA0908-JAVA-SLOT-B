# Task 9

Abstraction: Vehicle is abstract; Chargeable, Pass and PricingRule are interfaces.

Common source files are in `../src/`. Compile from the project root with `javac -d out src/*.java`. Run the relevant demo listed in the root README. Add your task-specific report page and the matching screenshot in this folder before committing.
