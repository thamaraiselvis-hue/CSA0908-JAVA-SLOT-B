# Time and Space Complexity
Let N be total parking slots across all floors, F be the number of floors, V be active vehicles, and K be vehicle categories.

| Operation / representation | Time | Extra space | Notes |
|---|---:|---:|---|
| Jagged-array allocation scan | O(N) worst case | O(1) beyond slots | Scans floors and slots until first free slot |
| Release by known floor/slot | O(1) | O(1) | Direct indexed access |
| Slot lookup by known indexes | O(1) | O(1) | Bounds check then access |
| Active registration lookup using HashMap | O(1) average; O(V) worst case | O(V) map storage | Hash collisions can degrade worst case |
| Registration search using array / ArrayList | O(V) | O(V) storage | Linear scan |
| Fee calculation | O(1) | O(1) | Basic hourly slab arithmetic |
| Delivery van time-window split | O(M) in this demo | O(1) | M is number of whole minutes in the session; production can compute interval intersections arithmetically |
| Vehicle object storage | O(V) | O(V) | Each vehicle/ticket contributes constant-size fields plus references |
| Parallel arrays search | O(V) | O(V) | Same asymptotic search, but index synchronisation is fragile |
| Free-slot stack approach | O(1) amortized allocate/release | O(N) additional | Requires correct stack maintenance and compatibility handling |

For F floors and N total slots, the jagged array uses O(N + F) space (row references plus slot references). A rectangular F × S array is O(FS) and may waste space when floor capacities differ. A jagged array is the appropriate representation for unequal floor capacities.
