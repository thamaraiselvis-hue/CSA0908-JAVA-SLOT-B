# Test Results — Actual execution

The following results were captured by compiling the project with `javac -d out src/*.java` and running each demo with OpenJDK in the current environment.

| Test | Input / scenario | Expected behaviour | Actual result | Status |
|---|---|---|---|---|
| Allocation | Facility capacities `{2,1}`, allocate 4 vehicles | First three allocated, fourth returns null | `[0,0]`, `[0,1]`, `[1,0]`, `null` | PASS |
| Release valid slot | Release floor 0 slot 1 | true | true | PASS |
| Release same slot twice | Release already-free slot | false | false | PASS |
| Invalid slot | Release floor 5 slot 0 | false | false | PASS |
| Two-wheeler fee | 130 minutes at Rs 10/hour | 3 started hours = Rs 30 | Rs 30.0 | PASS |
| Car fee | 130 minutes at Rs 30/hour | 3 started hours = Rs 90 | Rs 90.0 | PASS |
| EV fee | 130 minutes plus 10 kWh | Rs 90 + Rs 120 = Rs 210 | Rs 210.0 | PASS |
| Duplicate active registration | Enter same registration twice | Reject second entry | REJECTED | PASS |
| Zero-minute duration | 0 minutes | Rs 0 | Rs 0.0 | PASS |
| Fee boundary | Car, 61 minutes | 2 started hours = Rs 60 | Rs 60.0 | PASS |
| Exit before entry | Exit timestamp earlier than entry | Reject | REJECTED | PASS |
| E-bike | 45 minutes | Flat session fee assumption Rs 25 | Rs 25.0 | PASS |
| Delivery van in window | 10:00–11:00 | Double car rate = Rs 60 | Rs 60.0 | PASS |
| Delivery van outside window | 18:00–19:00 | Normal car rate = Rs 30 | Rs 30.0 | PASS |
| One-day pass | Valid date / next date | true / false | true / false | PASS |
| Integrated one-day pass | Visitor with valid pass | Parking fee waived | Rs 0.0 | PASS |
| Unequal five-floor capacity | `{2,3,1,4,2}` | Total capacity 12 | 12 | PASS |

## Hand calculation for daily collection
For a sample collection scenario: one two-wheeler parked 60 minutes = Rs 10; one car parked 61 minutes = 2 × Rs 30 = Rs 60; one EV parked 60 minutes plus 10 kWh charging = Rs 30 + Rs 120 = Rs 150. Total expected collection = Rs 10 + Rs 60 + Rs 150 = **Rs 220**. The test logic should be rerun with these three tickets in a single service session if the faculty expects an integrated daily-total console printout.

## Executed daily collection total
`DailyCollectionDemo` was also compiled and executed: two-wheeler (60 min) = Rs 10; car (61 min) = Rs 60; EV (60 min + 10 kWh) = Rs 150; total = **Rs 220**. See `screenshots/DailyCollectionDemo.png`.
Additional integrated Task 12 service-level tests: e-bike exit through `ParkingService` = Rs 25; delivery van exit 10:00–11:00 through `ParkingService` = Rs 60; valid visitor one-day pass through service = Rs 0; five-floor capacity = 12; monthly pass validity in its month = true.
