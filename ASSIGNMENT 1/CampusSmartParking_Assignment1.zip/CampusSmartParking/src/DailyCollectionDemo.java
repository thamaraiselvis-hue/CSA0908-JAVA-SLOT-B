public class DailyCollectionDemo {
 public static void main(String[] args) {
  double twoWheeler = new TwoWheeler("TN40AA0001").calculateFee(60);
  double car = new Car("TN40BB0002").calculateFee(61);
  ElectricCar ev = new ElectricCar("TN40CC0003");
  double electricCar = ev.calculateFee(60) + ev.chargingFee(10);
  double total = twoWheeler + car + electricCar;
  System.out.println("Two-wheeler (60 min): Rs " + twoWheeler);
  System.out.println("Car (61 min): Rs " + car);
  System.out.println("EV (60 min + 10 kWh): Rs " + electricCar);
  System.out.println("Daily collection total: Rs " + total);
 }
}
