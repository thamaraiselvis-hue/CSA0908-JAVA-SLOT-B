import java.util.Arrays;

public class ParkingFacility {
    private final String[][] slots;
    public ParkingFacility(int[] slotsPerFloor) {
        if (slotsPerFloor == null || slotsPerFloor.length == 0) throw new IllegalArgumentException("At least one floor is required");
        slots = new String[slotsPerFloor.length][];
        for (int f = 0; f < slotsPerFloor.length; f++) {
            if (slotsPerFloor[f] < 0) throw new IllegalArgumentException("Negative slot count");
            slots[f] = new String[slotsPerFloor[f]];
        }
    }
    public int[] allocate(String vehicleNo) {
        if (vehicleNo == null || vehicleNo.isBlank()) throw new IllegalArgumentException("Vehicle number is required");
        for (int f = 0; f < slots.length; f++) for (int s = 0; s < slots[f].length; s++) {
            if (slots[f][s] == null) { slots[f][s] = vehicleNo; return new int[]{f, s}; }
        }
        return null;
    }
    public boolean release(int floor, int slot) {
        if (floor < 0 || floor >= slots.length || slot < 0 || slot >= slots[floor].length || slots[floor][slot] == null) return false;
        slots[floor][slot] = null; return true;
    }
    public boolean isOccupied(int floor, int slot) {
        return floor >= 0 && floor < slots.length && slot >= 0 && slot < slots[floor].length && slots[floor][slot] != null;
    }
    public int totalSlots() { return Arrays.stream(slots).mapToInt(a -> a.length).sum(); }
    public int occupiedCount() { int n=0; for (String[] row: slots) for (String x: row) if (x!=null) n++; return n; }
}
