import java.time.*;
import java.util.*;

public class ParkingService {
    private final ParkingFacility facility;
    private final Map<String, ParkingTicket> active = new HashMap<>();
    private final PricingRule pricingRule = new TimeWindowPricingRule();
    public ParkingService(ParkingFacility facility) { this.facility=Objects.requireNonNull(facility); }
    public ParkingTicket enter(Vehicle v, LocalDateTime entry) {
        Objects.requireNonNull(v); Objects.requireNonNull(entry);
        if (active.containsKey(v.getRegNo())) throw new IllegalArgumentException("Duplicate active registration");
        int[] pos=facility.allocate(v.getRegNo()); if(pos==null) return null;
        ParkingTicket t=new ParkingTicket(v,entry,pos[0],pos[1]); active.put(v.getRegNo(),t); return t;
    }
    public double exit(String regNo, LocalDateTime out, UserType user, Pass pass) { return exit(regNo, out, user, pass, 0); }
    public double exit(String regNo, LocalDateTime out, UserType user, Pass pass, int kWh) {
        ParkingTicket t=active.get(regNo);
        if(t==null) throw new IllegalArgumentException("No active ticket");
        if(out.isBefore(t.getEntryTime())) throw new IllegalArgumentException("Exit before entry");
        double fee;
        if ((user==UserType.STUDENT || user==UserType.STAFF) && pass!=null && pass.isValid(out.toLocalDate())) fee=0.0;
        else if (user==UserType.VISITOR && pass!=null && pass.isValid(out.toLocalDate())) fee=0.0;
        else {
            fee=pricingRule.calculateFee(t.getVehicle(),t.getEntryTime(),out);
            if (t.getVehicle() instanceof Chargeable chargeable) fee += chargeable.chargingFee(kWh);
        }
        facility.release(t.getFloor(),t.getSlot()); t.close(); active.remove(regNo); return fee;
    }
    public int activeCount(){return active.size();}
}
