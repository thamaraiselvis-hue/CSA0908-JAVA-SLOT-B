import java.time.LocalDateTime;

public final class ParkingTicket {
    private static long nextId = 1000;
    private final long ticketId;
    private final Vehicle vehicle;
    private final LocalDateTime entryTime;
    private final int floor, slot;
    private boolean closed;
    public ParkingTicket(Vehicle vehicle, LocalDateTime entryTime, int floor, int slot) {
        if (vehicle == null || entryTime == null || floor < 0 || slot < 0) throw new IllegalArgumentException("Invalid ticket data");
        this.ticketId = ++nextId; this.vehicle = vehicle; this.entryTime = entryTime; this.floor=floor; this.slot=slot;
    }
    public long getTicketId(){return ticketId;} public Vehicle getVehicle(){return vehicle;}
    public LocalDateTime getEntryTime(){return entryTime;} public int getFloor(){return floor;} public int getSlot(){return slot;}
    public boolean isClosed(){return closed;} public void close(){closed=true;}
}
