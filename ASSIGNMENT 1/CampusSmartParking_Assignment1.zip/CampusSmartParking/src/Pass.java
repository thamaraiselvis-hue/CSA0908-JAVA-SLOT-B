import java.time.LocalDate;
interface Pass { boolean isValid(LocalDate date); }
final class MonthlyPass implements Pass {
    private final java.time.YearMonth validMonth;
    MonthlyPass(java.time.YearMonth validMonth) { this.validMonth = java.util.Objects.requireNonNull(validMonth); }
    public boolean isValid(LocalDate date) { return java.time.YearMonth.from(date).equals(validMonth); }
}
final class OneDayPass implements Pass {
    private final LocalDate validDate;
    OneDayPass(LocalDate validDate) { this.validDate = java.util.Objects.requireNonNull(validDate); }
    public boolean isValid(LocalDate date) { return validDate.equals(date); }
}
enum UserType { STUDENT, STAFF, VISITOR }
