import java.time.*;
interface PricingRule { double calculateFee(Vehicle vehicle, LocalDateTime in, LocalDateTime out); }
final class TimeWindowPricingRule implements PricingRule {
    private static final LocalTime START = LocalTime.of(9,0), END = LocalTime.of(17,0);
    public double calculateFee(Vehicle vehicle, LocalDateTime in, LocalDateTime out) {
        if (out.isBefore(in)) throw new IllegalArgumentException("Exit before entry");
        if (!(vehicle instanceof DeliveryVan)) return vehicle.calculateFee(in, out);
        // Split into minute segments: double car rate for time in [09:00,17:00), normal outside.
        long doubled=0, normal=0;
        LocalDateTime t=in.truncatedTo(java.time.temporal.ChronoUnit.MINUTES);
        LocalDateTime end=out.truncatedTo(java.time.temporal.ChronoUnit.MINUTES);
        while (t.isBefore(end)) {
            LocalTime clock=t.toLocalTime();
            if (!clock.isBefore(START) && clock.isBefore(END)) doubled++; else normal++;
            t=t.plusMinutes(1);
        }
        // Bill each pricing segment in started hours, preserving the time-window split.
        return ((doubled+59)/60)*60.0 + ((normal+59)/60)*30.0;
    }
}
