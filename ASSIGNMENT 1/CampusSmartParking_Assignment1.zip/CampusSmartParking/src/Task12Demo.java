import java.time.*;
public class Task12Demo {
 public static void main(String[] args) {
  EBike bike=new EBike("TN10EB0001");
  System.out.println("E-bike flat fee: Rs "+bike.calculateFee(45));
  PricingRule rule=new TimeWindowPricingRule();
  System.out.println("Delivery van 10:00-11:00 (double rate): Rs "+rule.calculateFee(new DeliveryVan("TN20DV0001"),LocalDateTime.of(2026,11,15,10,0),LocalDateTime.of(2026,11,15,11,0)));
  System.out.println("Delivery van 18:00-19:00 (normal rate): Rs "+rule.calculateFee(new DeliveryVan("TN20DV0002"),LocalDateTime.of(2026,11,15,18,0),LocalDateTime.of(2026,11,15,19,0)));
  OneDayPass valid=new OneDayPass(LocalDate.of(2026,11,15));
  System.out.println("Visitor one-day pass valid today: "+valid.isValid(LocalDate.of(2026,11,15)));
  System.out.println("Visitor one-day pass expired: "+valid.isValid(LocalDate.of(2026,11,16)));
  ParkingFacility fiveFloors=new ParkingFacility(new int[]{2,3,1,4,2});
  ParkingService service=new ParkingService(fiveFloors);
  ParkingTicket ebikeTicket=service.enter(new EBike("TN10EB0002"),LocalDateTime.of(2026,11,15,8,0));
  System.out.println("Integrated e-bike exit fee: Rs "+service.exit("TN10EB0002",LocalDateTime.of(2026,11,15,8,45),UserType.VISITOR,null));
  ParkingTicket vanTicket=service.enter(new DeliveryVan("TN20DV0003"),LocalDateTime.of(2026,11,15,10,0));
  System.out.println("Integrated delivery van exit fee: Rs "+service.exit("TN20DV0003",LocalDateTime.of(2026,11,15,11,0),UserType.VISITOR,null));
  ParkingTicket visitor=service.enter(new Car("TN30VIS001"),LocalDateTime.of(2026,11,15,8,0));
  double waived=service.exit("TN30VIS001",LocalDateTime.of(2026,11,15,9,0),UserType.VISITOR,valid);
  System.out.println("Integrated visitor one-day pass fee: Rs "+waived);
  System.out.println("Five-floor total capacity: "+fiveFloors.totalSlots());
  MonthlyPass monthly=new MonthlyPass(YearMonth.of(2026,11));
  System.out.println("Staff monthly pass valid this month: "+monthly.isValid(LocalDate.of(2026,11,20)));
 }
}
