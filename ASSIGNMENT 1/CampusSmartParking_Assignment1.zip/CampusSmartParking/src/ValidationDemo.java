import java.time.*;
public class ValidationDemo {
 public static void main(String[] args) {
  ParkingFacility f=new ParkingFacility(new int[]{1}); ParkingService s=new ParkingService(f);
  ParkingTicket t=s.enter(new TwoWheeler("TN01AA0001"),LocalDateTime.of(2026,11,15,9,0));
  System.out.println("Entry ticket: "+t.getTicketId()+" at ["+t.getFloor()+", "+t.getSlot()+"]");
  try{s.enter(new Car("TN01AA0001"),LocalDateTime.of(2026,11,15,9,5));}catch(Exception e){System.out.println("Duplicate registration: REJECTED");}
  System.out.println("Exit fee (60 min): Rs "+s.exit("TN01AA0001",LocalDateTime.of(2026,11,15,10,0),UserType.VISITOR,null));
  int[] last=f.allocate("TN02AA0002"); System.out.println("Last free slot allocated: ["+last[0]+", "+last[1]+"]");
  System.out.println("Invalid slot release: "+f.release(9,9));
  System.out.println("Zero-minute fee: Rs "+new TwoWheeler("TN03AA0003").calculateFee(0));
  System.out.println("61-minute car fee: Rs "+new Car("TN04AA0004").calculateFee(61));
  try{new Car("TN05AA0005").calculateFee(LocalDateTime.now(),LocalDateTime.now().minusMinutes(1));}catch(Exception e){System.out.println("Exit-before-entry: REJECTED");}
 }
}
