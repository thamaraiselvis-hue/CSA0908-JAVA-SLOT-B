import java.util.Objects;

abstract class Vehicle {
    private final String regNo;
    protected Vehicle(String regNo) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Registration number is required");
        this.regNo = regNo.trim().toUpperCase();
    }
    public String getRegNo() { return regNo; }
    protected abstract double ratePerHour();
    public double calculateFee(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("Minutes cannot be negative");
        int hours = (minutes + 59) / 60;
        return hours * ratePerHour();
    }
    public double calculateFee(java.time.LocalDateTime in, java.time.LocalDateTime out) {
        if (out.isBefore(in)) throw new IllegalArgumentException("Exit cannot be before entry");
        long minutes = java.time.Duration.between(in, out).toMinutes();
        if (minutes > Integer.MAX_VALUE) throw new IllegalArgumentException("Duration too long");
        return calculateFee((int) minutes);
    }
    @Override public boolean equals(Object o) { return o instanceof Vehicle v && regNo.equals(v.regNo); }
    @Override public int hashCode() { return Objects.hash(regNo); }
    @Override public String toString() { return getClass().getSimpleName() + "[" + regNo + "]"; }
}
class TwoWheeler extends Vehicle {
    TwoWheeler(String regNo) { super(regNo); }
    @Override protected double ratePerHour() { return 10.0; }
}
class Car extends Vehicle {
    Car(String regNo) { super(regNo); }
    @Override protected double ratePerHour() { return 30.0; }
}
class ElectricCar extends Car implements Chargeable {
    ElectricCar(String regNo) { super(regNo); }
    @Override public double chargingFee(int kWh) {
        if (kWh < 0) throw new IllegalArgumentException("kWh cannot be negative");
        return 12.0 * kWh;
    }
}
class EBike extends Vehicle {
    EBike(String regNo) { super(regNo); }
    @Override protected double ratePerHour() { return 0.0; }
    @Override public double calculateFee(int minutes) {
        if (minutes < 0) throw new IllegalArgumentException("Minutes cannot be negative");
        return minutes == 0 ? 0.0 : 25.0; // Assumed flat fee per parking session
    }
}
class DeliveryVan extends Vehicle {
    DeliveryVan(String regNo) { super(regNo); }
    @Override protected double ratePerHour() { return 30.0; }
}
interface Chargeable { double chargingFee(int kWh); }
